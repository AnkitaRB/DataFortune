import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'poc';
  headers=['Description', 'Reference Account', 'Narrative Code', 'Liability Balance', 'Modified liability balance', 'Credit Limit', 'Monthly expenses', 'Modified monthly expenses', 'Exclusion Reason'];
  data=[
    {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },
  {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },
  {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },
  {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },
  {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },
  {
    'Description': 'Monthly Rent',
    'ReferenceAccount': 0,
    'NarrativeCode': '3333',
    'LiabilityBalance': 26000,
    'Modifiedliabilitybalance': '12112',
    'CreditLimit': 2600,
    'Monthlyexpenses': 3000,
    'Modifiedmonthlyexpenses': '211',
    'ExclusionReason': 'None'

  },]
}
